<?php
header('Content-Type: application/json');

try {
    if (!isset($_POST['aws-access-key']) || !isset($_POST['aws-secret-key']) || !isset($_POST['aws-region'])) {
        throw new Exception('Todos os campos são obrigatórios');
    }

    $config = [
        'AWS_ACCESS_KEY' => $_POST['aws-access-key'],
        'AWS_SECRET_KEY' => $_POST['aws-secret-key'],
        'AWS_REGION' => $_POST['aws-region']
    ];

    // Criar conteúdo do arquivo de configuração
    $config_content = "<?php\n";
    foreach ($config as $key => $value) {
        $config_content .= "define('$key', '$value');\n";
    }

    // Salvar configurações em um arquivo
    if (file_put_contents('config.php', $config_content)) {
        echo json_encode([
            'success' => true,
            'message' => 'Configurações salvas com sucesso'
        ]);
    } else {
        throw new Exception('Erro ao salvar arquivo de configuração');
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 