<?php
header('Content-Type: application/json');

// Obter informações do sistema
$platform = php_uname();
$cpu_usage = 0.0; // Em um ambiente real, você usaria uma biblioteca específica para obter o uso da CPU
$memory_usage = 74.1; // Em um ambiente real, você usaria uma biblioteca específica para obter o uso da memória

// Retornar informações como JSON
echo json_encode([
    'platform' => $platform,
    'cpu' => $cpu_usage,
    'memory' => $memory_usage
]); 