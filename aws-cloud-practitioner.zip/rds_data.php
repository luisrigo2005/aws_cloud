<?php
require 'config.php';

header('Content-Type: application/json');

try {
    $dsn = "pgsql:host=" . RDS_HOST . ";port=" . RDS_PORT . ";dbname=" . RDS_DBNAME;
    $pdo = new PDO($dsn, RDS_USERNAME, RDS_PASSWORD);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Exemplo de consulta - ajuste conforme sua necessidade
    $stmt = $pdo->query("SELECT * FROM sua_tabela LIMIT 100");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($data);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'error' => 'Erro ao conectar ao banco de dados: ' . $e->getMessage()
    ]);
} 