<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AWS Cloud Practitioner Essentials</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand d-flex align-items-center" href="#">
                <img src="img/aws-logo.png" alt="AWS Logo" height="30" class="me-2">
                AWS Cloud Practitioner
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="#system-info">Informações do Sistema</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#s3">Amazon S3</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#rds">Amazon RDS</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#config">Configurações</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="jumbotron">
            <h1 class="display-4">Bem-vindo ao AWS Cloud Practitioner Essentials</h1>
            <p class="lead">Este é um exemplo de aplicação que demonstra a integração com serviços AWS.</p>
        </div>

        <div id="system-info" class="section">
            <h2>Informações do Sistema</h2>
            <div class="card">
                <div class="card-body">
                    <p><strong>Plataforma:</strong> <span id="platform">Windows-11-10.0.26100-SP0</span></p>
                    <p><strong>CPU:</strong> <span id="cpu-usage">0.0%</span></p>
                    <p><strong>Memória:</strong> <span id="memory-usage">74.1%</span></p>
                </div>
            </div>
        </div>

        <div id="s3" class="section mt-4">
            <h2>Amazon S3</h2>
            <div class="card">
                <div class="card-body">
                    <h5>Gerenciamento de Arquivos</h5>
                    <form action="upload.php" method="post" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="file" class="form-label">Selecione um arquivo</label>
                            <input type="file" class="form-control" id="file" name="file">
                        </div>
                        <button type="submit" class="btn btn-primary">Upload</button>
                    </form>
                    <div class="mt-3">
                        <h6>Arquivos Disponíveis</h6>
                        <div id="file-list">
                            <!-- Lista de arquivos será carregada aqui -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="rds" class="section mt-4">
            <h2>Amazon RDS</h2>
            <div class="card">
                <div class="card-body">
                    <h5>Banco de Dados PostgreSQL</h5>
                    <div class="mb-3">
                        <button class="btn btn-primary" onclick="loadDatabaseData()">Carregar Dados</button>
                    </div>
                    <div id="database-content">
                        <!-- Conteúdo do banco de dados será carregado aqui -->
                    </div>
                </div>
            </div>
        </div>

        <div id="config" class="section mt-4">
            <h2>Configurações</h2>
            <div class="card">
                <div class="card-body">
                    <form id="aws-config-form">
                        <div class="mb-3">
                            <label for="aws-access-key" class="form-label">AWS Access Key</label>
                            <input type="text" class="form-control" id="aws-access-key" name="aws-access-key">
                        </div>
                        <div class="mb-3">
                            <label for="aws-secret-key" class="form-label">AWS Secret Key</label>
                            <input type="password" class="form-control" id="aws-secret-key" name="aws-secret-key">
                        </div>
                        <div class="mb-3">
                            <label for="aws-region" class="form-label">AWS Region</label>
                            <input type="text" class="form-control" id="aws-region" name="aws-region" value="us-east-1">
                        </div>
                        <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/main.js"></script>
</body>
</html> 