<?php
require 'vendor/autoload.php';
require 'config.php';

use Aws\S3\S3Client;
use Aws\Exception\AwsException;

header('Content-Type: application/json');

try {
    if (!isset($_FILES['file'])) {
        throw new Exception('Nenhum arquivo enviado');
    }

    $file = $_FILES['file'];
    $bucket = 'seu-bucket-s3'; // Substitua pelo nome do seu bucket

    $s3Client = new S3Client([
        'version' => 'latest',
        'region'  => AWS_REGION,
        'credentials' => [
            'key'    => AWS_ACCESS_KEY,
            'secret' => AWS_SECRET_KEY,
        ]
    ]);

    $result = $s3Client->putObject([
        'Bucket' => $bucket,
        'Key'    => $file['name'],
        'SourceFile' => $file['tmp_name'],
        'ContentType' => $file['type']
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Arquivo enviado com sucesso',
        'url' => $result['ObjectURL']
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
} 