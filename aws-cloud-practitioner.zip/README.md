# AWS Cloud Practitioner Essentials

Esta é uma aplicação de demonstração que integra serviços AWS, incluindo Amazon S3 e Amazon RDS.

## Requisitos

- PHP 7.4 ou superior
- Composer
- Extensão PDO para PostgreSQL
- Credenciais AWS válidas

## Instalação

1. Clone este repositório
2. Instale as dependências usando o Composer:
   ```bash
   composer require aws/aws-sdk-php
   ```
3. Configure suas credenciais AWS no painel de configurações da aplicação
4. Configure as credenciais do banco de dados RDS no arquivo `config.php`

## Estrutura do Projeto

- `index.php` - Página principal da aplicação
- `system_info.php` - API para informações do sistema
- `upload.php` - API para upload de arquivos para S3
- `rds_data.php` - API para consulta ao banco de dados RDS
- `save_config.php` - API para salvar configurações
- `config.php` - Arquivo de configuração (gerado automaticamente)
- `css/style.css` - Estilos da aplicação
- `js/main.js` - JavaScript da aplicação

## Funcionalidades

1. **Informações do Sistema**
   - Monitoramento de CPU e memória
   - Informações da plataforma

2. **Amazon S3**
   - Upload de arquivos
   - Listagem de arquivos
   - Download de arquivos

3. **Amazon RDS**
   - Conexão com banco de dados PostgreSQL
   - Visualização de dados
   - Consultas personalizadas

4. **Configurações**
   - Gerenciamento de credenciais AWS
   - Configuração de região
   - Configuração de banco de dados

## Segurança

- As credenciais AWS são armazenadas localmente
- Todas as requisições são validadas
- Senhas e chaves secretas são protegidas

## Suporte

Para suporte, entre em contato com o administrador do sistema. 