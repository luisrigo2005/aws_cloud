// Função para atualizar informações do sistema
function updateSystemInfo() {
    fetch('system_info.php')
        .then(response => response.json())
        .then(data => {
            document.getElementById('platform').textContent = data.platform;
            document.getElementById('cpu-usage').textContent = data.cpu + '%';
            document.getElementById('memory-usage').textContent = data.memory + '%';
        })
        .catch(error => console.error('Erro ao atualizar informações do sistema:', error));
}

// Função para carregar dados do banco de dados
function loadDatabaseData() {
    fetch('rds_data.php')
        .then(response => response.json())
        .then(data => {
            const content = document.getElementById('database-content');
            if (data.error) {
                content.innerHTML = `<div class="alert alert-danger">${data.error}</div>`;
            } else {
                // Criar tabela com os dados
                let table = '<table class="table table-striped">';
                if (data.length > 0) {
                    // Cabeçalho da tabela
                    table += '<thead><tr>';
                    Object.keys(data[0]).forEach(key => {
                        table += `<th>${key}</th>`;
                    });
                    table += '</tr></thead>';
                    
                    // Corpo da tabela
                    table += '<tbody>';
                    data.forEach(row => {
                        table += '<tr>';
                        Object.values(row).forEach(value => {
                            table += `<td>${value}</td>`;
                        });
                        table += '</tr>';
                    });
                    table += '</tbody>';
                } else {
                    table += '<tbody><tr><td colspan="100%">Nenhum dado encontrado</td></tr></tbody>';
                }
                table += '</table>';
                content.innerHTML = table;
            }
        })
        .catch(error => {
            document.getElementById('database-content').innerHTML = 
                '<div class="alert alert-danger">Erro ao carregar dados do banco de dados</div>';
            console.error('Erro:', error);
        });
}

// Função para salvar configurações AWS
document.getElementById('aws-config-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('save_config.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Configurações salvas com sucesso!');
        } else {
            alert('Erro ao salvar configurações: ' + data.error);
        }
    })
    .catch(error => {
        alert('Erro ao salvar configurações');
        console.error('Erro:', error);
    });
});

// Atualizar informações do sistema a cada 5 segundos
setInterval(updateSystemInfo, 5000);

// Carregar informações iniciais
updateSystemInfo(); 